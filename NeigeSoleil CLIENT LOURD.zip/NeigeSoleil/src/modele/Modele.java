package modele;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import controleur.Appartement;
import controleur.Client;
import controleur.Location;
import controleur.Proprietaire;
import controleur.Utilisateur;


public class Modele {
	//liste des requetes SQL 
	private static BDD uneBdd = new BDD("localhost:3306","ns", "root", ""); 
	
	/************ Requetes User ****************/
	public static Utilisateur selectWhereUser(String email, String mdp) {
		Utilisateur unUser = null; 
		String requete ="select * from utilisateur where email ='"+email+"' and mdp='"+mdp+"';";
		try {
			uneBdd.seConnecter();
			Statement unStat = uneBdd.getMaConnexion().createStatement(); //prepare en PDO
			ResultSet unRes = unStat.executeQuery(requete); //execute en PDO
			if (unRes.next()) { //s'il y a un resultat 
				unUser = new Utilisateur (unRes.getInt("idutilisateur"), unRes.getString("nom"), 
						unRes.getString("prenom"), unRes.getString("email"), 
						unRes.getString("mdp"), unRes.getString("role"), unRes.getString("date_creation")); 
			}
			unStat.close();
			uneBdd.seDeConnecter();
		}
		catch(SQLException exp) {
			System.out.println("Erreur d'execution de la requete :" + requete);
		}
		return unUser; 
	}
	/*********************** Proprietaie********************/
	public static void insertProprietaire(Proprietaire unProprietaire) {
	    String requete = "insert into proprietaire values (null, '"
	            + unProprietaire.getNom() + "','"
	            + unProprietaire.getPrenom() + "','"
	            + unProprietaire.getEmail() + "','"
	            + unProprietaire.getMdp() + "','"
	            + unProprietaire.getAdresse() + "');";
	    
	    executerRequete(requete);
	}
	
	
	public static void deleteProprietaire(int idproprio) {
	    String requete = "delete from proprietaire where idproprio = " + idproprio + ";";
	    executerRequete(requete);
	}

	
	public static void updateProprietaire(Proprietaire unProprietaire) {
	    String requete = "update proprietaire set nom ='"
	            + unProprietaire.getNom() + "', prenom ='"
	            + unProprietaire.getPrenom() + "', email ='"
	            + unProprietaire.getEmail() + "', mdp ='"
	            + unProprietaire.getMdp() + "', adresse ='"
	            + unProprietaire.getAdresse()
	            + "' where idproprio = " + unProprietaire.getIdproprio() + ";";
	    
	    executerRequete(requete);
	}

	
	public static ArrayList<Proprietaire> selectAllProprietaires(String filtre) {
	    ArrayList<Proprietaire> lesProprietaires = new ArrayList<Proprietaire>();
	    String requete;

	    if (filtre.equals("")) {
	        requete = "select * from proprietaire;";
	    } else {
	        requete = "select * from proprietaire where nom like '%" + filtre
	                + "%' or prenom like '%" + filtre
	                + "%' or email like '%" + filtre
	                + "%' or adresse like '%" + filtre + "%';";
	    }

	    try {
	        uneBdd.seConnecter();
	        Statement unStat = uneBdd.getMaConnexion().createStatement();

	        ResultSet desResultats = unStat.executeQuery(requete);
	        while (desResultats.next()) {
	            Proprietaire unProprietaire = new Proprietaire(
	                    desResultats.getInt("idproprio"),
	                    desResultats.getString("nom"),
	                    desResultats.getString("prenom"),
	                    desResultats.getString("email"),
	                    desResultats.getString("mdp"),
	                    desResultats.getString("adresse")
	            );
	            lesProprietaires.add(unProprietaire);
	        }

	        unStat.close();
	        uneBdd.seDeConnecter();

	    } catch (SQLException exp) {
	        System.out.println("Erreur d'execution de la requete :" + requete);
	    }

	    return lesProprietaires;
	}

	/**************************Clients********************/
	public static void insertClient(Client unClient) {
	    String requete = "insert into client values (null, '"
	            + unClient.getNom() + "','"
	            + unClient.getPrenom() + "','"
	            + unClient.getEmail() + "','"
	            + unClient.getMdp() + "','"
	            + unClient.getAdresse() + "');";
	    
	    executerRequete(requete);
	}

	public static void deleteClient(int idclient) {
	    String requete = "delete from client where idclient = " + idclient + ";";
	    executerRequete(requete);
	}
	

	public static void updateClient(Client unClient) {
	    String requete = "update client set nom ='"
	            + unClient.getNom() + "', prenom ='"
	            + unClient.getPrenom() + "', email ='"
	            + unClient.getEmail() + "', mdp ='"
	            + unClient.getMdp() + "', adresse ='"
	            + unClient.getAdresse()
	            + "' where idclient = " + unClient.getIdclient() + ";";
	    
	    executerRequete(requete);
	}

	public static ArrayList<Client> selectAllClients(String filtre) {
	    ArrayList<Client> lesClients = new ArrayList<Client>();
	    String requete;

	    if (filtre.equals("")) {
	        requete = "select * from client;";
	    } else {
	        requete = "select * from client where nom like '%" + filtre
	                + "%' or prenom like '%" + filtre
	                + "%' or email like '%" + filtre
	                + "%' or adresse like '%" + filtre + "%';";
	    }

	    try {
	        uneBdd.seConnecter();
	        Statement unStat = uneBdd.getMaConnexion().createStatement();

	        ResultSet desResultats = unStat.executeQuery(requete);
	        while (desResultats.next()) {
	            Client unClient = new Client(
	                    desResultats.getInt("idclient"),
	                    desResultats.getString("nom"),
	                    desResultats.getString("prenom"),
	                    desResultats.getString("email"),
	                    desResultats.getString("mdp"),
	                    desResultats.getString("adresse")
	            );
	            lesClients.add(unClient);
	        }

	        unStat.close();
	        uneBdd.seDeConnecter();

	    } catch (SQLException exp) {
	        System.out.println("Erreur d'execution de la requete :" + requete);
	    }

	    return lesClients;
	}
	 /*************Appartement************/
	
	public static void insertAppartement(Appartement unAppartement) {
	    String requete = "insert into appartement values (null, '"
	            + unAppartement.getAdresse() + "', '"
	            + unAppartement.getSurface() + "', '"
	            + unAppartement.getDesignation() + "', "
	            + unAppartement.getIdproprio() + ", '"
	            + unAppartement.getImage() + "');";
	    
	    executerRequete(requete);
	}

	
	public static void deleteAppartement(int idappart) {
	    String requete = "delete from appartement where idappart = " + idappart + ";";
	    executerRequete(requete);
	}

	
	public static void updateAppartement(Appartement unAppartement) {
	    String requete = "update appartement set adresse ='"
	            + unAppartement.getAdresse() + "', surface ='"
	            + unAppartement.getSurface() + "', designation ='"
	            + unAppartement.getDesignation() + "', idproprio = "
	            + unAppartement.getIdproprio() + ", image ='"
	            + unAppartement.getImage()
	            + "' where idappart = " + unAppartement.getIdappart() + ";";
	    
	    executerRequete(requete);
	}

	public static ArrayList<Appartement> selectAllAppartements(String filtre) {
	    ArrayList<Appartement> lesAppartements = new ArrayList<Appartement>();
	    String requete;

	    if (filtre.equals("")) {
	        requete = "select * from appartement;";
	    } else {
	        requete = "select * from appartement where adresse like '%" + filtre
	                + "%' or designation like '%" + filtre
	                + "%' or surface like '%" + filtre + "%';";
	    }

	    try {
	        uneBdd.seConnecter();
	        Statement unStat = uneBdd.getMaConnexion().createStatement();

	        ResultSet desResultats = unStat.executeQuery(requete);
	        while (desResultats.next()) {
	            Appartement unAppartement = new Appartement(
	                    desResultats.getInt("idappart"),
	                    desResultats.getString("adresse"),
	                    desResultats.getFloat("surface"),
	                    desResultats.getString("designation"),
	                    desResultats.getInt("idproprio"),
	                    desResultats.getString("image")
	            );
	            lesAppartements.add(unAppartement);
	        }

	        unStat.close();
	        uneBdd.seDeConnecter();

	    } catch (SQLException exp) {
	        System.out.println("Erreur d'execution de la requete :" + requete);
	    }

	    return lesAppartements;
	}


	 /*****************Location*******************/
	
	public static void insertLocation(Location uneLocation) {
	    String requete = "insert into location values (null, '"
	            + uneLocation.getDateDebut() + "', '"
	            + uneLocation.getDateFin() + "', '"
	            + uneLocation.getDescription() + "', "
	            + uneLocation.getIdappart() + ", "
	            + uneLocation.getIdclient() + ");";
	    
	    executerRequete(requete);
	}

	public static void deleteLocation(int idlocation) {
	    String requete = "delete from location where idlocation = " + idlocation + ";";
	    executerRequete(requete);
	}

	public static void updateLocation(Location uneLocation) {
	    String requete = "update location set dateDebut ='"
	            + uneLocation.getDateDebut() + "', dateFin ='"
	            + uneLocation.getDateFin() + "', description ='"
	            + uneLocation.getDescription() + "', idappart = "
	            + uneLocation.getIdappart() + ", idclient = "
	            + uneLocation.getIdclient()
	            + " where idlocation = " + uneLocation.getIdlocation() + ";";
	    
	    executerRequete(requete);
	}

	public static ArrayList<Location> selectAllLocations(String filtre) {
	    ArrayList<Location> lesLocations = new ArrayList<Location>();
	    String requete;

	    if (filtre.equals("")) {
	        requete = "select * from location;";
	    } else {
	        requete = "select * from location where description like '%" + filtre
	                + "%' or dateDebut like '%" + filtre
	                + "%' or dateFin like '%" + filtre + "%';";
	    }

	    try {
	        uneBdd.seConnecter();
	        Statement unStat = uneBdd.getMaConnexion().createStatement();

	        ResultSet desResultats = unStat.executeQuery(requete);
	        while (desResultats.next()) {
	            Location uneLocation = new Location(
	                    desResultats.getInt("idlocation"),
	                    desResultats.getString("dateDebut"),
	                    desResultats.getString("dateFin"),
	                    desResultats.getString("description"),
	                    desResultats.getInt("idappart"),
	                    desResultats.getInt("idclient")
	            );
	            lesLocations.add(uneLocation);
	        }

	        unStat.close();
	        uneBdd.seDeConnecter();

	    } catch (SQLException exp) {
	        System.out.println("Erreur d'execution de la requete :" + requete);
	    }

	    return lesLocations;
	}

	
	/******************* Autres méthodes *******************/
	public static void executerRequete (String requete) {
		 try {
				uneBdd.seConnecter();
				Statement unStat = uneBdd.getMaConnexion().createStatement(); 
				unStat.execute(requete);
				unStat.close();
				uneBdd.seDeConnecter();
			 }
			 catch(SQLException exp) {
					System.out.println("Erreur d'execution de la requete :" + requete);
			}
	}

	public static void updateUser(Utilisateur unUser) {
		String requete = "update utilisateur set nom ='" + unUser.getNom()
				+ "',prenom ='" + unUser.getPrenom()+"', email = '"
				+unUser.getEmail() + "', mdp ='" + unUser.getMdp() 
				 + "', role ='" + unUser.getRole()  + "', date_creation ='" + unUser.getDate_creation()
				+ "' where idutilisateur = " + unUser.getIduser() +";"; 
		
		executerRequete (requete); 
	}
}