-- ============================
-- RESET DE LA BASE
-- ============================
DROP DATABASE IF EXISTS ns;
CREATE DATABASE ns
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;
 
USE ns;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";
 
-- ============================
-- TABLE : proprietaire
-- ============================
DROP TABLE IF EXISTS proprietaire;
CREATE TABLE proprietaire (
  idproprio INT NOT NULL AUTO_INCREMENT,
  nom VARCHAR(50) NOT NULL,
  prenom VARCHAR(50) NOT NULL,
  email VARCHAR(50) NOT NULL,
  mdp VARCHAR(255) NOT NULL,
  adresse TEXT NOT NULL,
  PRIMARY KEY (idproprio),
  UNIQUE KEY email (email)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
 
-- ============================
-- TABLE : appartement
-- ============================
DROP TABLE IF EXISTS appartement;
CREATE TABLE appartement (
  idappart INT NOT NULL AUTO_INCREMENT,
  adresse TEXT NOT NULL,
  surface DECIMAL(10,2) NOT NULL,
  designation VARCHAR(50) NOT NULL,
  idproprio INT NOT NULL,
  image VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (idappart),
  KEY idproprio (idproprio)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
 
-- ============================
-- TABLE : client
-- ============================
DROP TABLE IF EXISTS client;
CREATE TABLE client (
  idclient INT NOT NULL AUTO_INCREMENT,
  nom VARCHAR(50) NOT NULL,
  prenom VARCHAR(50) NOT NULL,
  email VARCHAR(50) NOT NULL,
  mdp VARCHAR(255) NOT NULL,
  adresse TEXT NOT NULL,
  PRIMARY KEY (idclient),
  UNIQUE KEY email (email)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
 
-- ============================
-- TABLE : location
-- ============================
DROP TABLE IF EXISTS location;
CREATE TABLE location (
  idlocation INT NOT NULL AUTO_INCREMENT,
  dateDebut DATE NOT NULL,
  dateFin DATE DEFAULT NULL,
  description TEXT,
  idappart INT NOT NULL,
  idclient INT NOT NULL,
  PRIMARY KEY (idlocation),
  KEY idappart (idappart),
  KEY idclient (idclient)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
 
-- ============================
-- TABLE : utilisateur
-- ============================
DROP TABLE IF EXISTS utilisateur;
CREATE TABLE utilisateur (
  idutilisateur INT NOT NULL AUTO_INCREMENT,
  nom VARCHAR(50) NOT NULL,
  prenom VARCHAR(50) NOT NULL,
  email VARCHAR(50) NOT NULL,
  mdp VARCHAR(255) NOT NULL,
  role ENUM('admin','agent','client') DEFAULT 'client',
  date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (idutilisateur),
  UNIQUE KEY email (email)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

 insert into utilisateur values (NULL, "Jeremy", "Idir", "a@gmail.com","123", "admin", "2026-02-02");
 
 INSERT INTO proprietaire VALUES 
(NULL,'Dupont','Pierre','pierre.dupont@gmail.com','1234','12 Rue de la Paix, Paris'),
(NULL,'Martin','Sophie','sophie.martin@gmail.com','1234','5 Avenue Victor Hugo, Lyon'),
(NULL,'Bernard','Jean','jean.bernard@gmail.com','1234','8 Rue du Port, Marseille'),
(NULL,'Leroy','Claire','claire.leroy@gmail.com','1234','3 Rue des Fleurs, Bordeaux'),
(NULL,'Moreau','Antoine','antoine.moreau@gmail.com','1234','17 Boulevard Haussmann, Paris');

INSERT INTO client VALUES
(NULL,'Petit','Lucas','lucas.petit@gmail.com','1234','22 Rue Lafayette, Paris'),
(NULL,'Girard','Emma','emma.girard@gmail.com','1234','9 Rue du Lac, Annecy'),
(NULL,'Roux','Hugo','hugo.roux@gmail.com','1234','14 Avenue des Alpes, Grenoble'),
(NULL,'Blanc','Camille','camille.blanc@gmail.com','1234','6 Rue Saint-Michel, Toulouse'),
(NULL,'Faure','Lucie','lucie.faure@gmail.com','1234','31 Rue de la République, Lyon');

INSERT INTO appartement VALUES
(NULL,'12 Rue de la Mer, Biarritz',65.00,'T2 vue mer',1,NULL),
(NULL,'5 Avenue du Ski, Chamonix',80.00,'Chalet montagne',2,NULL),
(NULL,'3 Rue du Port, Marseille',55.00,'Studio centre ville',3,NULL),
(NULL,'18 Rue des Pins, Bordeaux',90.00,'T3 avec jardin',4,NULL),
(NULL,'7 Rue de la Plage, Nice',70.00,'Appartement plage',5,NULL);

INSERT INTO location VALUES
(NULL,'2026-01-10','2026-03-10','Location courte durée',1,1),
(NULL,'2026-02-15','2026-04-15','Séjour ski',2,2),
(NULL,'2026-03-01','2026-05-01','Location meublée',3,3),
(NULL,'2026-04-05','2026-06-05','Vacances été',4,4),
(NULL,'2026-05-20','2026-07-20','Location saisonnière',5,5);
 