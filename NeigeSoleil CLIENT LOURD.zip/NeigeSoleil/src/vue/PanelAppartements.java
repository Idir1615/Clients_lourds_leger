package vue;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;

import controleur.Appartement;
import controleur.Controleur;
import controleur.Proprietaire;
import controleur.Tableau;

public class PanelAppartements extends PanelPrincipal implements ActionListener
{
private JPanel panelForm = new JPanel();


private JTextField txtAdresse = new JTextField();
private JTextField txtSurface = new JTextField();
private JTextField txtDesignation = new JTextField();
private JTextField txtImage = new JTextField();
private static JComboBox<String> txtIdProprio = new JComboBox<String>();

private JButton btAnnuler = new JButton("Annuler");
private JButton btValider = new JButton("Valider");
private JButton btModifier = new JButton("Modifier");
private JButton btSupprimer = new JButton("Supprimer");

private JTable tableApparts;
private JScrollPane scroll;
private Tableau unTableau;

private JPanel panelFiltre = new JPanel();
private JTextField txtFiltre = new JTextField();
private JButton btFiltrer = new JButton("Filtrer");

private JLabel lbNb = new JLabel();

public PanelAppartements(String titre){
	super(titre);
	
	// FILTRE
	panelFiltre.setBounds(450,80,450,30);
	panelFiltre.setLayout(new GridLayout(1,3,10,10));
	panelFiltre.setBackground(Color.gray);
	panelFiltre.add(new JLabel("Filtrer par :"));
	panelFiltre.add(txtFiltre);
	panelFiltre.add(btFiltrer);
	add(panelFiltre);
	
	// FORM
	panelForm.setBounds(50,80,300,300);
	panelForm.setLayout(new GridLayout(7,2,10,10));
	panelForm.setBackground(Color.gray);
	
	panelForm.add(new JLabel("Adresse :"));
	panelForm.add(txtAdresse);
	
	panelForm.add(new JLabel("Surface :"));
	panelForm.add(txtSurface);
	
	panelForm.add(new JLabel("Désignation :"));
	panelForm.add(txtDesignation);
	
	panelForm.add(new JLabel("Image :"));
	panelForm.add(txtImage);
	
	panelForm.add(new JLabel("ID Propriétaire :"));
	panelForm.add(txtIdProprio);
	
	panelForm.add(btAnnuler);
	panelForm.add(btValider);
	panelForm.add(btModifier);
	panelForm.add(btSupprimer);
	
	add(panelForm);
	
	btModifier.setEnabled(false);
	btSupprimer.setEnabled(false);
	
	btAnnuler.addActionListener(this);
	btValider.addActionListener(this);
	btModifier.addActionListener(this);
	btSupprimer.addActionListener(this);
	btFiltrer.addActionListener(this);
	txtFiltre.addActionListener(this);
	
	String[] entetes = {"ID","Adresse","Surface","Désignation","ID Proprio","Image"};
	
	unTableau = new Tableau(obtenirDonnees(""), entetes);
	tableApparts = new JTable(unTableau);
	
	scroll = new JScrollPane(tableApparts);
	scroll.setBounds(450,120,450,220);
	add(scroll);
	
	tableApparts.addMouseListener(new MouseAdapter(){
		public void mouseClicked(MouseEvent e){
			int num = tableApparts.getSelectedRow();
			
			txtAdresse.setText(unTableau.getValueAt(num,1).toString());
			txtSurface.setText(unTableau.getValueAt(num,2).toString());
			txtDesignation.setText(unTableau.getValueAt(num,3).toString());
			txtImage.setText(unTableau.getValueAt(num,5).toString());
			
			btModifier.setEnabled(true);
			btSupprimer.setEnabled(true);
		}
	});
	
	lbNb.setBounds(500,350,400,20);
	lbNb.setText("Nombre d'appartements : "+unTableau.getRowCount());
	add(lbNb);
	
	remplirIdProprietaires();
}

public static void remplirIdProprietaires(){
	ArrayList<Proprietaire> liste = Controleur.selectAllProprietaires("");
	txtIdProprio.removeAllItems();
	
	for(Proprietaire p : liste){
		txtIdProprio.addItem(p.getIdproprio()+"-"+p.getNom());
	}
}

public Object[][] obtenirDonnees(String filtre){
	ArrayList<Appartement> liste = Controleur.selectAllAppartements(filtre);
	Object[][] matrice = new Object[liste.size()][6];
	
	int i=0;
	for(Appartement a : liste){
		matrice[i][0]=a.getIdappart();
		matrice[i][1]=a.getAdresse();
		matrice[i][2]=a.getSurface();
		matrice[i][3]=a.getDesignation();
		matrice[i][4]=a.getIdproprio();
		matrice[i][5]=a.getImage();
		i++;
	}
	return matrice;
}

public void viderChamps(){
	txtAdresse.setText("");
	txtSurface.setText("");
	txtDesignation.setText("");
	txtImage.setText("");
	
	btModifier.setEnabled(false);
	btSupprimer.setEnabled(false);
}

public void insertAppartement(){
	int idproprio = Integer.parseInt(txtIdProprio.getSelectedItem().toString().split("-")[0]);
	
	Appartement a = new Appartement(
		txtAdresse.getText(),
		Float.parseFloat(txtSurface.getText()),
		txtDesignation.getText(),
		idproprio,
		txtImage.getText()
	);
	
	Controleur.insertAppartement(a);
	unTableau.setDonnees(obtenirDonnees(""));
	lbNb.setText("Nombre d'appartements : "+unTableau.getRowCount());
	viderChamps();
	PanelLocations.remplirCombo();
}

public void updateAppartement(){
	int num = tableApparts.getSelectedRow();
	int id = Integer.parseInt(unTableau.getValueAt(num,0).toString());
	int idproprio = Integer.parseInt(txtIdProprio.getSelectedItem().toString().split("-")[0]);
	
	Appartement a = new Appartement(
		id,
		txtAdresse.getText(),
		Float.parseFloat(txtSurface.getText()),
		txtDesignation.getText(),
		idproprio,
		txtImage.getText()
	);
	
	Controleur.updateAppartement(a);
	unTableau.setDonnees(obtenirDonnees(""));
	viderChamps();
	PanelLocations.remplirCombo();
}

public void deleteAppartement(){
	int num = tableApparts.getSelectedRow();
	int id = Integer.parseInt(unTableau.getValueAt(num,0).toString());
	
	Controleur.deleteAppartement(id);
	unTableau.setDonnees(obtenirDonnees(""));
	lbNb.setText("Nombre d'appartements : "+unTableau.getRowCount());
	viderChamps();
	PanelLocations.remplirCombo();
}

public void actionPerformed(ActionEvent e){
	if(e.getSource()==btAnnuler) viderChamps();
	else if(e.getSource()==btValider) insertAppartement();
	else if(e.getSource()==btModifier) updateAppartement();
	else if(e.getSource()==btSupprimer) deleteAppartement();
	else if(e.getSource()==btFiltrer || e.getSource()==txtFiltre)
		unTableau.setDonnees(obtenirDonnees(txtFiltre.getText()));
}


}
