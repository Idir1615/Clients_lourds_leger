package vue;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;

import controleur.Client;
import controleur.Appartement;
import controleur.Location;
import controleur.Controleur;
import controleur.Tableau;

public class PanelLocations extends PanelPrincipal implements ActionListener
{
private JPanel panelForm = new JPanel();


private JTextField txtDateDebut = new JTextField();
private JTextField txtDateFin = new JTextField();
private JTextField txtDescription = new JTextField();

private static JComboBox<String> txtIdAppart = new JComboBox<>();
private static JComboBox<String> txtIdClient = new JComboBox<>();

private JButton btAnnuler = new JButton("Annuler");
private JButton btValider = new JButton("Valider");
private JButton btModifier = new JButton("Modifier");
private JButton btSupprimer = new JButton("Supprimer");

private JTable table;
private JScrollPane scroll;
private Tableau unTableau;

private JPanel panelFiltre = new JPanel();
private JTextField txtFiltre = new JTextField();
private JButton btFiltrer = new JButton("Filtrer");

private JLabel lbNb = new JLabel();

public PanelLocations(String titre){
	super(titre);
	
	panelFiltre.setBounds(450,80,450,30);
	panelFiltre.setLayout(new GridLayout(1,3,10,10));
	panelFiltre.setBackground(Color.gray);
	panelFiltre.add(new JLabel("Filtrer par :"));
	panelFiltre.add(txtFiltre);
	panelFiltre.add(btFiltrer);
	add(panelFiltre);
	
	panelForm.setBounds(50,80,300,300);
	panelForm.setLayout(new GridLayout(7,2,10,10));
	panelForm.setBackground(Color.gray);
	
	panelForm.add(new JLabel("Date début :"));
	panelForm.add(txtDateDebut);
	
	panelForm.add(new JLabel("Date fin :"));
	panelForm.add(txtDateFin);
	
	panelForm.add(new JLabel("Description :"));
	panelForm.add(txtDescription);
	
	panelForm.add(new JLabel("ID Appartement :"));
	panelForm.add(txtIdAppart);
	
	panelForm.add(new JLabel("ID Client :"));
	panelForm.add(txtIdClient);
	
	panelForm.add(btAnnuler);
	panelForm.add(btValider);
	panelForm.add(btModifier);
	panelForm.add(btSupprimer);
	
	add(panelForm);
	
	btModifier.setEnabled(false);
	btSupprimer.setEnabled(false);
	
	btAnnuler.addActionListener(this);
	btValider.addActionListener(this);
	btModifier.addActionListener(this);
	btSupprimer.addActionListener(this);
	btFiltrer.addActionListener(this);
	txtFiltre.addActionListener(this);
	
	String[] entetes = {"ID","Date début","Date fin","Description","ID Appart","ID Client"};
	
	unTableau = new Tableau(obtenirDonnees(""), entetes);
	table = new JTable(unTableau);
	
	scroll = new JScrollPane(table);
	scroll.setBounds(450,120,450,220);
	add(scroll);
	
	table.addMouseListener(new MouseAdapter(){
		public void mouseClicked(MouseEvent e){
			int num = table.getSelectedRow();
			
			txtDateDebut.setText(unTableau.getValueAt(num,1).toString());
			txtDateFin.setText(unTableau.getValueAt(num,2).toString());
			txtDescription.setText(unTableau.getValueAt(num,3).toString());
			
			btModifier.setEnabled(true);
			btSupprimer.setEnabled(true);
		}
	});
	
	lbNb.setBounds(500,350,400,20);
	lbNb.setText("Nombre de locations : "+unTableau.getRowCount());
	add(lbNb);
	
	remplirCombo();
}

public static void remplirCombo(){
	txtIdAppart.removeAllItems();
	txtIdClient.removeAllItems();
	
	for(Appartement a : Controleur.selectAllAppartements("")){
		txtIdAppart.addItem(a.getIdappart()+"-"+a.getDesignation());
	}
	
	for(Client c : Controleur.selectAllClients("")){
		txtIdClient.addItem(c.getIdclient()+"-"+c.getNom());
	}
}

public Object[][] obtenirDonnees(String filtre){
	ArrayList<Location> liste = Controleur.selectAllLocations(filtre);
	Object[][] matrice = new Object[liste.size()][6];
	
	int i=0;
	for(Location l : liste){
		matrice[i][0]=l.getIdlocation();
		matrice[i][1]=l.getDateDebut();
		matrice[i][2]=l.getDateFin();
		matrice[i][3]=l.getDescription();
		matrice[i][4]=l.getIdappart();
		matrice[i][5]=l.getIdclient();
		i++;
	}
	return matrice;
}

public void viderChamps(){
	txtDateDebut.setText("");
	txtDateFin.setText("");
	txtDescription.setText("");
	btModifier.setEnabled(false);
	btSupprimer.setEnabled(false);
}

public void insertLocation(){
	int idapp = Integer.parseInt(txtIdAppart.getSelectedItem().toString().split("-")[0]);
	int idcli = Integer.parseInt(txtIdClient.getSelectedItem().toString().split("-")[0]);
	
	Location l = new Location(
		txtDateDebut.getText(),
		txtDateFin.getText(),
		txtDescription.getText(),
		idapp,
		idcli
	);
	
	Controleur.insertLocation(l);
	unTableau.setDonnees(obtenirDonnees(""));
	lbNb.setText("Nombre de locations : "+unTableau.getRowCount());
	viderChamps();
}

public void updateLocation(){
	int num = table.getSelectedRow();
	int id = Integer.parseInt(unTableau.getValueAt(num,0).toString());
	
	int idapp = Integer.parseInt(txtIdAppart.getSelectedItem().toString().split("-")[0]);
	int idcli = Integer.parseInt(txtIdClient.getSelectedItem().toString().split("-")[0]);
	
	Location l = new Location(
		id,
		txtDateDebut.getText(),
		txtDateFin.getText(),
		txtDescription.getText(),
		idapp,
		idcli
	);
	
	Controleur.updateLocation(l);
	unTableau.setDonnees(obtenirDonnees(""));
	viderChamps();
}

public void deleteLocation(){
	int num = table.getSelectedRow();
	int id = Integer.parseInt(unTableau.getValueAt(num,0).toString());
	
	Controleur.deleteLocation(id);
	unTableau.setDonnees(obtenirDonnees(""));
	lbNb.setText("Nombre de locations : "+unTableau.getRowCount());
	viderChamps();
	
}

public void actionPerformed(ActionEvent e){
	if(e.getSource()==btAnnuler) viderChamps();
	else if(e.getSource()==btValider) insertLocation();
	else if(e.getSource()==btModifier) updateLocation();
	else if(e.getSource()==btSupprimer) deleteLocation();
	else if(e.getSource()==btFiltrer || e.getSource()==txtFiltre)
		unTableau.setDonnees(obtenirDonnees(txtFiltre.getText()));
}

}
