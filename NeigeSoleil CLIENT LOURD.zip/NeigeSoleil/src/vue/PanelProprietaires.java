package vue;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;

import controleur.Proprietaire;
import controleur.Controleur;
import controleur.Tableau;

public class PanelProprietaires extends PanelPrincipal implements ActionListener
{
private JPanel panelForm = new JPanel();

private JTextField txtNom = new JTextField();
private JTextField txtPrenom = new JTextField();
private JTextField txtEmail = new JTextField();
private JPasswordField txtMdp = new JPasswordField();
private JTextField txtAdresse = new JTextField();

private JButton btAnnuler = new JButton("Annuler");
private JButton btValider = new JButton("Valider");
private JButton btModifier = new JButton("Modifier");
private JButton btSupprimer = new JButton("Supprimer");

private JTable tableProprietaires;
private JScrollPane scroll;
private Tableau unTableau;

private JPanel panelFiltre = new JPanel();
private JTextField txtFiltre = new JTextField();
private JButton btFiltrer = new JButton("Filtrer");

private JLabel lbNb = new JLabel();

public PanelProprietaires(String titre) {
	super(titre);
	
	panelFiltre.setBounds(450, 80, 450, 30);
	panelFiltre.setLayout(new GridLayout(1,3,10,10));
	panelFiltre.setBackground(Color.gray);
	panelFiltre.add(new JLabel("Filtrer par :"));
	panelFiltre.add(txtFiltre);
	panelFiltre.add(btFiltrer);
	add(panelFiltre);
	
	panelForm.setBounds(50, 80, 300, 300);
	panelForm.setLayout(new GridLayout(7,2,10,10));
	panelForm.setBackground(Color.gray);
	
	panelForm.add(new JLabel("Nom :"));
	panelForm.add(txtNom);
	
	panelForm.add(new JLabel("Prénom :"));
	panelForm.add(txtPrenom);
	
	panelForm.add(new JLabel("Email :"));
	panelForm.add(txtEmail);
	
	panelForm.add(new JLabel("Mot de passe :"));
	panelForm.add(txtMdp);
	
	panelForm.add(new JLabel("Adresse :"));
	panelForm.add(txtAdresse);
	
	panelForm.add(btAnnuler);
	panelForm.add(btValider);
	panelForm.add(btModifier);
	panelForm.add(btSupprimer);
	
	add(panelForm);
	
	btModifier.setEnabled(false);
	btSupprimer.setEnabled(false);
	
	btAnnuler.addActionListener(this);
	btValider.addActionListener(this);
	btModifier.addActionListener(this);
	btSupprimer.addActionListener(this);
	btFiltrer.addActionListener(this);
	txtFiltre.addActionListener(this);
	
	String[] entetes = {"ID","Nom","Prénom","Email", "Adresse"};
	
	unTableau = new Tableau(obtenirDonnees(""), entetes);
	tableProprietaires = new JTable(unTableau);
	
	scroll = new JScrollPane(tableProprietaires);
	scroll.setBounds(450, 120, 450, 220);
	add(scroll);
	
	tableProprietaires.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent e) {
			int num = tableProprietaires.getSelectedRow();
			
			txtNom.setText(unTableau.getValueAt(num,1).toString());
			txtPrenom.setText(unTableau.getValueAt(num,2).toString());
			txtEmail.setText(unTableau.getValueAt(num,3).toString());
			txtMdp.setText(unTableau.getValueAt(num,4).toString());
			txtAdresse.setText(unTableau.getValueAt(num,5).toString());
			
			btModifier.setEnabled(true);
			btSupprimer.setEnabled(true);
		}
	});
	
	lbNb.setBounds(500,350,400,20);
	lbNb.setText("Nombre de propriétaires : " + unTableau.getRowCount());
	add(lbNb);
}

public Object[][] obtenirDonnees(String filtre){
	ArrayList<Proprietaire> liste = Controleur.selectAllProprietaires(filtre);
	Object[][] matrice = new Object[liste.size()][6];
	
	int i=0;
	for(Proprietaire p : liste){
		matrice[i][0]=p.getIdproprio();
		matrice[i][1]=p.getNom();
		matrice[i][2]=p.getPrenom();
		matrice[i][3]=p.getEmail();
	
		matrice[i][4]=p.getAdresse();
		i++;
	}
	return matrice;
}

public void viderChamps(){
	txtNom.setText("");
	txtPrenom.setText("");
	txtEmail.setText("");
	txtMdp.setText("");
	txtAdresse.setText("");
	
	btModifier.setEnabled(false);
	btSupprimer.setEnabled(false);
}

public void insertProprietaire(){
	Proprietaire p = new Proprietaire(
		txtNom.getText(),
		txtPrenom.getText(),
		txtEmail.getText(),
		txtMdp.getText(),
		txtAdresse.getText()
	);
	
	Controleur.insertProprietaire(p);
	unTableau.setDonnees(obtenirDonnees(""));
	lbNb.setText("Nombre de propriétaires : " + unTableau.getRowCount());
	viderChamps();
	PanelAppartements.remplirIdProprietaires();
	PanelLocations.remplirCombo();
}

public void updateProprietaire(){
	int num = tableProprietaires.getSelectedRow();
	int id = Integer.parseInt(unTableau.getValueAt(num,0).toString());
	
	Proprietaire p = new Proprietaire(
		id,
		txtNom.getText(),
		txtPrenom.getText(),
		txtEmail.getText(),
		txtMdp.getText(),
		txtAdresse.getText()
	);
	
	Controleur.updateProprietaire(p);
	unTableau.setDonnees(obtenirDonnees(""));
	viderChamps();
	PanelAppartements.remplirIdProprietaires();
	PanelLocations.remplirCombo();
}

public void deleteProprietaire(){
	int num = tableProprietaires.getSelectedRow();
	int id = Integer.parseInt(unTableau.getValueAt(num,0).toString());
	
	Controleur.deleteProprietaire(id);
	unTableau.setDonnees(obtenirDonnees(""));
	lbNb.setText("Nombre de propriétaires : " + unTableau.getRowCount());
	viderChamps();
	PanelAppartements.remplirIdProprietaires();
	PanelLocations.remplirCombo();
}

public void actionPerformed(ActionEvent e){
	if(e.getSource()==btAnnuler) viderChamps();
	else if(e.getSource()==btValider) insertProprietaire();
	else if(e.getSource()==btModifier) updateProprietaire();
	else if(e.getSource()==btSupprimer) deleteProprietaire();
	else if(e.getSource()==btFiltrer || e.getSource()==txtFiltre)
		unTableau.setDonnees(obtenirDonnees(txtFiltre.getText()));
}


}
