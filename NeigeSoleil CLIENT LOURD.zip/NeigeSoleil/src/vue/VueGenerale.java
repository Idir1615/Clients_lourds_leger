package vue;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import controleur.NS;

public class VueGenerale extends JFrame implements ActionListener
{
private JPanel panelMenu = new JPanel();

private JButton btProfil = new JButton("Profil"); 
private JButton btAppartements = new JButton("Appartements"); 
private JButton btClients = new JButton("Clients"); 
private JButton btProprietaires = new JButton("Propriétaires"); 
private JButton btLocations = new JButton("Locations"); 
private JButton btQuitter = new JButton("Quitter"); 

// Création des panels
private PanelProfil unPanelProfil = new PanelProfil("Gestion du Profil"); 
private PanelAppartements unPanelAppartements = new PanelAppartements("Gestion des Appartements"); 
private PanelClients unPanelClients = new PanelClients("Gestion des Clients"); 
private PanelProprietaires unPanelProprietaires = new PanelProprietaires("Gestion des Propriétaires"); 
private PanelLocations unPanelLocations = new PanelLocations("Gestion des Locations"); 

public VueGenerale() {
	this.setTitle("Application Immobilière Iris");
	this.setBounds(200, 10, 1000, 500);
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	this.setResizable(false);
	this.getContentPane().setBackground(Color.gray);
	this.setLayout(null);
	
	// Panel menu
	this.panelMenu.setBounds(100, 10, 800, 30);
	this.panelMenu.setBackground(Color.gray);
	this.panelMenu.setLayout(new GridLayout(1, 6, 10, 10));
	
	this.panelMenu.add(this.btProfil); 
	this.panelMenu.add(this.btAppartements);
	this.panelMenu.add(this.btClients);
	this.panelMenu.add(this.btProprietaires);
	this.panelMenu.add(this.btLocations);
	this.panelMenu.add(this.btQuitter);
	
	this.add(this.panelMenu); 
	
	// Boutons écoutables
	this.btProfil.addActionListener(this);
	this.btAppartements.addActionListener(this);
	this.btClients.addActionListener(this);
	this.btProprietaires.addActionListener(this);
	this.btLocations.addActionListener(this);
	this.btQuitter.addActionListener(this);
	
	// Ajout des panels
	this.add(this.unPanelProfil); 
	this.add(this.unPanelAppartements);
	this.add(this.unPanelClients);
	this.add(this.unPanelProprietaires);
	this.add(this.unPanelLocations);
	
	this.setVisible(true);
}

public void afficherPanel(int choix)
{
	this.unPanelProfil.setVisible(false);
	this.unPanelAppartements.setVisible(false);
	this.unPanelClients.setVisible(false);
	this.unPanelProprietaires.setVisible(false);
	this.unPanelLocations.setVisible(false);
	
	switch (choix) {
	case 1: this.unPanelProfil.setVisible(true); break;
	case 2: this.unPanelAppartements.setVisible(true); break;
	case 3: this.unPanelClients.setVisible(true); break;
	case 4: this.unPanelProprietaires.setVisible(true); break;
	case 5: this.unPanelLocations.setVisible(true); break;
	}
}

@Override
public void actionPerformed(ActionEvent e) {
	
	if (e.getSource() == this.btQuitter) {
		int retour = JOptionPane.showConfirmDialog(this,
				"Voulez-vous quitter l'application",
				"Quitter l'application",
				JOptionPane.YES_NO_OPTION);
		
		if (retour == 0) {
		NS.creerDetruireVueGenerale(false);
			NS.rendreVisibleVueConnexion(true);
		}
	}
	else if (e.getSource() == this.btProfil) {
		this.afficherPanel(1);
	}
	else if (e.getSource() == this.btAppartements) {
		this.afficherPanel(2);
	}
	else if (e.getSource() == this.btClients) {
		this.afficherPanel(3);
	}
	else if (e.getSource() == this.btProprietaires) {
		this.afficherPanel(4);
	}
	else if (e.getSource() == this.btLocations) {
		this.afficherPanel(5);
	}
}


}
