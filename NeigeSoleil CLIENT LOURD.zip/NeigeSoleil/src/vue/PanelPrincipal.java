package vue;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;

public abstract class PanelPrincipal extends JPanel
{
	public PanelPrincipal(String titre) {
		//les caractéristiques communs à tous les panels 
		
		this.setBounds(10, 80, 960, 400);
		this.setBackground(Color.gray);
		this.setLayout(null);
		
		JLabel lbTitre = new JLabel(titre); 
		lbTitre.setBounds(400, 10, 400, 20);
		Font unePolice = new Font("Arial", Font.BOLD, 18); 
		lbTitre.setFont(unePolice);
		
		this.add(lbTitre); 
		
		this.setVisible(false);
	}
}
