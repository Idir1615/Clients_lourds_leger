package vue;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
 

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import controleur.Controleur;
import controleur.NS;
import controleur.Utilisateur;

public class VueConnexion extends JFrame  implements ActionListener 
{
	private JPanel panelForm = new JPanel(); // div en html
	private JTextField txtEmail = new JTextField("admin@ns.com"); 
	private JPasswordField txtMdp =new JPasswordField("admin123"); 
	private JButton btAnnuler = new JButton("Annuler"); 
	private JButton btValider = new JButton("Valider"); 
	
	public VueConnexion () {
		this.setTitle("CL Scolarite Iris " );
		this.setBounds(200, 10, 300, 540);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		this.getContentPane().setBackground(Color.gray);
		this.setLayout(null);
		
		//ajout du logo Iris 
		ImageIcon uneImage = new ImageIcon( "src/images/logo.png");
		JLabel lbLogo = new JLabel(uneImage); 
		lbLogo.setBounds(30, 30, 240, 280);
		this.add(lbLogo); 
		
		//Placement du formulaire panelForm 
		this.panelForm.setBounds(30, 340, 240, 140);
		this.panelForm.setBackground(Color.gray);
		this.panelForm.setLayout(new GridLayout(3,2));
		
		this.panelForm.add(new JLabel("Email : ")); 
		this.panelForm.add(this.txtEmail); 
		
		this.panelForm.add(new JLabel("MDP : ")); 
		this.panelForm.add(this.txtMdp); 
		
		this.panelForm.add(this.btAnnuler); 
		this.panelForm.add(this.btValider); 
		
		this.add(this.panelForm); 
		
		//rendre les boutons ecoutables 
		this.btAnnuler.addActionListener(this);
		this.btValider.addActionListener(this);
		
		
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		 if (e.getSource() == this.btAnnuler) {
			 this.viderChamps (); 
		 }
		 else if (e.getSource() == this.btValider) {
			 this.traitement (); 
		 }
	}

	public void viderChamps() {
		this.txtEmail.setText("");
		this.txtMdp.setText("");
	}
	public void traitement () {
		String email = this.txtEmail.getText(); 
		String mdp = new String(this.txtMdp.getPassword()); 
		
		if (email.equals("") || mdp.equals("")) {
			JOptionPane.showMessageDialog(this,"Veuillez remplir tous les champs");
		}
		else {
				//rechercher l'user dans la BDD 
			Utilisateur unUser = Controleur.selectWhereUser(email, mdp); 
			if (unUser == null) {
				JOptionPane.showMessageDialog(this,"Veuillez vérifier les identifiants."); 
			}else {
				JOptionPane.showMessageDialog(this,"Bienvenue "+unUser.getNom()+" "
						+unUser.getPrenom()); 
				
				//on ouvre la vue génerale 
				NS.rendreVisibleVueConnexion(false);
				NS.creerDetruireVueGenerale(true);
				
				//save to userconnecte 
				NS.setUserConnecte(unUser);
				
				//actualiser les infos userConnecte 
				PanelProfil.actualiserInfosUser();
			}
			
		}
	}
	
}