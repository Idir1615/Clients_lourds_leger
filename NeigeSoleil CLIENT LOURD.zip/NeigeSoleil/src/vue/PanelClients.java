package vue;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;

import controleur.Client;
import controleur.Controleur;
import controleur.Tableau;

public class PanelClients extends PanelPrincipal implements ActionListener
{
private JPanel panelForm = new JPanel();

private JTextField txtNom = new JTextField();
private JTextField txtPrenom = new JTextField();
private JTextField txtEmail = new JTextField();
private JPasswordField txtMdp = new JPasswordField();
private JTextField txtAdresse = new JTextField();

private JButton btAnnuler = new JButton("Annuler");
private JButton btValider = new JButton("Valider");
private JButton btModifier = new JButton("Modifier");
private JButton btSupprimer = new JButton("Supprimer");

private JTable tableClients;
private JScrollPane scrollClients;
private Tableau unTableau;

private JPanel panelFiltre = new JPanel();
private JTextField txtFiltre = new JTextField();
private JButton btFiltrer = new JButton("Filtrer");

private JLabel lbNbClients = new JLabel();

public PanelClients(String titre) {
	super(titre);
	
	// FILTRE
	this.panelFiltre.setBounds(450, 80, 450, 30);
	this.panelFiltre.setBackground(Color.gray);
	this.panelFiltre.setLayout(new GridLayout(1, 3, 10, 10));
	this.panelFiltre.add(new JLabel("Filtrer par :"));
	this.panelFiltre.add(this.txtFiltre);
	this.panelFiltre.add(this.btFiltrer);
	this.add(this.panelFiltre);
	
	// FORMULAIRE
	this.panelForm.setBounds(50, 80, 300, 300);
	this.panelForm.setBackground(Color.gray);
	this.panelForm.setLayout(new GridLayout(7, 2, 10, 10));
	
	this.panelForm.add(new JLabel("Nom :"));
	this.panelForm.add(this.txtNom);
	
	this.panelForm.add(new JLabel("Prénom :"));
	this.panelForm.add(this.txtPrenom);
	
	this.panelForm.add(new JLabel("Email :"));
	this.panelForm.add(this.txtEmail);
	
	this.panelForm.add(new JLabel("Mot de passe :"));
	this.panelForm.add(this.txtMdp);
	
	this.panelForm.add(new JLabel("Adresse :"));
	this.panelForm.add(this.txtAdresse);
	
	this.panelForm.add(this.btAnnuler);
	this.panelForm.add(this.btValider);
	
	this.panelForm.add(this.btModifier);
	this.panelForm.add(this.btSupprimer);
	
	this.add(this.panelForm);
	
	this.btModifier.setEnabled(false);
	this.btSupprimer.setEnabled(false);
	
	// LISTENERS
	this.btAnnuler.addActionListener(this);
	this.btValider.addActionListener(this);
	this.btModifier.addActionListener(this);
	this.btSupprimer.addActionListener(this);
	this.btFiltrer.addActionListener(this);
	this.txtFiltre.addActionListener(this);
	
	// TABLE
	String[] entetes = {"ID", "Nom", "Prénom", "Email", "Adresse"};
	
	this.unTableau = new Tableau(this.obtenirDonnees(""), entetes);
	this.tableClients = new JTable(this.unTableau);
	
	this.scrollClients = new JScrollPane(this.tableClients);
	this.scrollClients.setBounds(450, 120, 450, 220);
	this.add(this.scrollClients);
	
	// CLICK TABLE
	this.tableClients.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent e) {
			int numLigne = tableClients.getSelectedRow();
			
			txtNom.setText(unTableau.getValueAt(numLigne, 1).toString());
			txtPrenom.setText(unTableau.getValueAt(numLigne, 2).toString());
			txtEmail.setText(unTableau.getValueAt(numLigne, 3).toString());
			txtMdp.setText(unTableau.getValueAt(numLigne, 4).toString());
			txtAdresse.setText(unTableau.getValueAt(numLigne, 5).toString());
			
			btModifier.setEnabled(true);
			btSupprimer.setEnabled(true);
		}
	});
	
	// NB
	this.lbNbClients.setBounds(500, 350, 400, 20);
	this.lbNbClients.setText("Nombre de clients : " + this.unTableau.getRowCount());
	this.add(this.lbNbClients);
}

public Object[][] obtenirDonnees(String filtre) {
	ArrayList<Client> lesClients = Controleur.selectAllClients(filtre);
	Object[][] matrice = new Object[lesClients.size()][5];
	
	int i = 0;
	for (Client c : lesClients) {
		matrice[i][0] = c.getIdclient();
		matrice[i][1] = c.getNom();
		matrice[i][2] = c.getPrenom();
		matrice[i][3] = c.getEmail();
	
		matrice[i][4] = c.getAdresse();
		i++;
	}
	return matrice;
}

public void viderChamps() {
	txtNom.setText("");
	txtPrenom.setText("");
	txtEmail.setText("");
	txtMdp.setText("");
	txtAdresse.setText("");
	
	btModifier.setEnabled(false);
	btSupprimer.setEnabled(false);
}

public void insertClient() {
	Client c = new Client(
		txtNom.getText(),
		txtPrenom.getText(),
		txtEmail.getText(),
		txtMdp.getText(),
		txtAdresse.getText()
	);
	
	Controleur.insertClient(c);
	unTableau.setDonnees(this.obtenirDonnees(""));
	lbNbClients.setText("Nombre de clients : " + unTableau.getRowCount());
	viderChamps();
	PanelAppartements.remplirIdProprietaires();
	PanelLocations.remplirCombo();
}

public void updateClient() {
	int num = tableClients.getSelectedRow();
	int id = Integer.parseInt(unTableau.getValueAt(num, 0).toString());
	
	Client c = new Client(
		id,
		txtNom.getText(),
		txtPrenom.getText(),
		txtEmail.getText(),
		txtMdp.getText(),
		txtAdresse.getText()
	);
	
	Controleur.updateClient(c);
	unTableau.setDonnees(this.obtenirDonnees(""));
	viderChamps();
	PanelAppartements.remplirIdProprietaires();
	PanelLocations.remplirCombo();
}

public void deleteClient() {
	int num = tableClients.getSelectedRow();
	int id = Integer.parseInt(unTableau.getValueAt(num, 0).toString());
	
	Controleur.deleteClient(id);
	unTableau.setDonnees(this.obtenirDonnees(""));
	lbNbClients.setText("Nombre de clients : " + unTableau.getRowCount());
	viderChamps();
	PanelAppartements.remplirIdProprietaires();
	PanelLocations.remplirCombo();
}

public void actionPerformed(ActionEvent e) {
	if (e.getSource() == btAnnuler) viderChamps();
	else if (e.getSource() == btValider) insertClient();
	else if (e.getSource() == btModifier) updateClient();
	else if (e.getSource() == btSupprimer) deleteClient();
	else if (e.getSource() == btFiltrer || e.getSource() == txtFiltre)
		unTableau.setDonnees(obtenirDonnees(txtFiltre.getText()));
}


}
