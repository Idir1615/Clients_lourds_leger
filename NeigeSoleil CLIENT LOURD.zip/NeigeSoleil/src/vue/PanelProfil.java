package vue;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import controleur.Controleur;
import controleur.NS;
import controleur.Utilisateur;
import controleur.Utilisateur;

public class PanelProfil extends PanelPrincipal implements ActionListener
{
	private static Utilisateur unUser = null; 
	
	private static JTextArea txtInfos = new JTextArea(); 
	
	private JButton  btModifier = new JButton("Modifier"); 
	private JButton  btAnnuler = new JButton("Annuler"); 
	private JButton  btValider= new JButton("Valider"); 
	
	private JPanel panelForm = new JPanel (); 
	
	private JTextField txtNom = new JTextField(); 
	private JTextField txtPrenom = new JTextField(); 
	private JTextField txtEmail = new JTextField(); 
	private JTextField txtRole = new JTextField(); 
	private JTextField txtDateCreation = new JTextField(); 
	private JPasswordField txtMdp = new JPasswordField(); 
	
	public PanelProfil(String titre) {
		super(titre);
		 
		//placement du JtextArea 
		this.txtInfos.setBounds(60, 100, 250, 180);
		this.txtInfos.setBackground(Color.gray);
		this.add(this.txtInfos);
		
		actualiserInfosUser();
		
		this.btModifier.setBounds(140, 300, 100, 30);
		this.add(this.btModifier); 
		
		this.panelForm.setBounds(440, 100, 250, 220);
		this.panelForm.setBackground(Color.gray);
		this.panelForm.setLayout(new GridLayout(7,2, 10,10));
		
		this.panelForm.add(new JLabel("Nom User : ")); 
		this.panelForm.add(this.txtNom); 
		
		this.panelForm.add(new JLabel("Prénom User : ")); 
		this.panelForm.add(this.txtPrenom); 
		
		this.panelForm.add(new JLabel("Email User : ")); 
		this.panelForm.add(this.txtEmail);
		
		this.panelForm.add(new JLabel("MDP User : ")); 
		this.panelForm.add(this.txtMdp); 
		this.panelForm.add(new JLabel("Role User : ")); 
		this.panelForm.add(this.txtRole);
		this.panelForm.add(new JLabel("Date Creation : ")); 
		this.panelForm.add(this.txtDateCreation);
		
		this.panelForm.add(this.btAnnuler); 
		this.panelForm.add(this.btValider);
		
		this.add(this.panelForm); 
		
		this.panelForm.setVisible(false);
		
		this.btAnnuler.addActionListener(this);
		this.btModifier.addActionListener(this);
		this.btValider.addActionListener(this);
	}
	public static void actualiserInfosUser() {
		unUser = NS.getUserConnecte(); 
		if (unUser != null) {
			txtInfos.setText("\n ----- Infos du profil ------\n"
					+ "\n\n Nom User    : " + unUser.getNom()
					+ "\n\n Prénom User : " + unUser.getPrenom()
					+ "\n\n Email User  : " + unUser.getEmail()
					+ "\n\n Role User  : " + unUser.getRole()
					+ "\n\n Date Creation : " + unUser.getDate_creation()
					+ "\n\n ____________________________________");
		}
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == this.btModifier) {
			this.panelForm.setVisible(true);
			if (unUser != null) {
			//remplir les champs 
			this.txtNom.setText(unUser.getNom());
			this.txtPrenom.setText(unUser.getPrenom());
			this.txtEmail.setText(unUser.getEmail());
			this.txtMdp.setText(unUser.getMdp());
			this.txtRole.setText(unUser.getRole());
			this.txtDateCreation.setText(unUser.getDate_creation());
			}
		}
		else if (e.getSource() == this.btAnnuler) {
			viderChamps (); 
		}
		else if (e.getSource() == this.btValider) {
			updateUser(); 
		}
	}
	public void viderChamps() {
		this.txtNom.setText("");
		this.txtPrenom.setText("");
		this.txtEmail.setText("");
		this.txtMdp.setText("");
		this.txtRole.setText("");
		this.txtDateCreation.setText("");
	}
	
	public void updateUser() {
		//modification en BDD 
		unUser.setNom(this.txtNom.getText());
		unUser.setPrenom(this.txtPrenom.getText());
		unUser.setEmail(this.txtEmail.getText());
		unUser.setMdp(new String(this.txtMdp.getPassword()));
		unUser.setRole(this.txtRole.getText());
		unUser.setDate_creation(this.txtDateCreation.getText());
		
		Controleur.updateUser(unUser); 
		
		JOptionPane.showMessageDialog(this, "Profil Modifie");
		this.panelForm.setVisible(false);
		actualiserInfosUser();
	}
}
