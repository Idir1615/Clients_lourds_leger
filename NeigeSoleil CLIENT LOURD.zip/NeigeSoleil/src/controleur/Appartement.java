package controleur;

public class Appartement {
	
	private int idappart;
	private String adresse; 
	private float surface; 
	private String designation;
	private int idproprio;
	private String image;
	
	
	
	
	public Appartement(int idappart, String adresse, float surface, String designation, int idproprio, String image) {
		super();
		this.idappart = idappart;
		this.adresse = adresse;
		this.surface = surface;
		this.designation = designation;
		this.idproprio = idproprio;
		this.image = image;
	}
	

	
	public Appartement( String adresse, float surface, String designation, int idproprio, String image) {
		super();
		this.idappart = 0;
		this.adresse = adresse;
		this.surface = surface;
		this.designation = designation;
		this.idproprio = idproprio;
		this.image = image;
	}



	public int getIdappart() {
		return idappart;
	}



	public void setIdappart(int idappart) {
		this.idappart = idappart;
	}



	public String getAdresse() {
		return adresse;
	}



	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}



	public float getSurface() {
		return surface;
	}



	public void setSurface(float surface) {
		this.surface = surface;
	}



	public String getDesignation() {
		return designation;
	}



	public void setDesignation(String designation) {
		this.designation = designation;
	}



	public int getIdproprio() {
		return idproprio;
	}



	public void setIdproprio(int idproprio) {
		this.idproprio = idproprio;
	}



	public String getImage() {
		return image;
	}



	public void setImage(String image) {
		this.image = image;
	}
	
	
	
	
	
}




