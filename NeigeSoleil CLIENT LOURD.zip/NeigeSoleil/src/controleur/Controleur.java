package controleur;

import java.util.ArrayList;

import modele.Modele;

public class Controleur {

	public static Utilisateur selectWhereUser(String email, String mdp) {
		//controler email, controler mdp 
		
		return Modele.selectWhereUser(email, mdp);
	}

	/***********Client*********/
	public static void insertClient(Client unClient) {
	    // contrôler les données du client si besoin
	    
	    Modele.insertClient(unClient);
	}

	public static ArrayList<Client> selectAllClients(String filtre) {
	    return Modele.selectAllClients(filtre);
	}

	public static void deleteClient(int idclient) {
	    Modele.deleteClient(idclient);
	}

	public static void updateClient(Client unClient) {
	    Modele.updateClient(unClient);
	}


	public static void updateUser(Utilisateur unUser) {
		Modele.updateUser(unUser); 
		
	}
	
	/******************Proprietaire**************/
	public static void insertProprietaire(Proprietaire unProprietaire) {
	    // contrôler les données
	    
	    Modele.insertProprietaire(unProprietaire);
	}

	public static ArrayList<Proprietaire> selectAllProprietaires(String filtre) {
	    return Modele.selectAllProprietaires(filtre);
	}

	public static void deleteProprietaire(int idproprio) {
	    Modele.deleteProprietaire(idproprio);
	}

	public static void updateProprietaire(Proprietaire unProprietaire) {
	    Modele.updateProprietaire(unProprietaire);
	}

	
	
	/*************Appartement*************/
	public static void insertAppartement(Appartement unAppartement) {
	    // contrôler les données
	    
	    Modele.insertAppartement(unAppartement);
	}

	public static ArrayList<Appartement> selectAllAppartements(String filtre) {
	    return Modele.selectAllAppartements(filtre);
	}

	public static void deleteAppartement(int idappart) {
	    Modele.deleteAppartement(idappart);
	}

	public static void updateAppartement(Appartement unAppartement) {
	    Modele.updateAppartement(unAppartement);
	}

	
	
	/******************Location*****************/
	public static void insertLocation(Location uneLocation) {
	    // contrôler les données
	    
	    Modele.insertLocation(uneLocation);
	}

	public static ArrayList<Location> selectAllLocations(String filtre) {
	    return Modele.selectAllLocations(filtre);
	}

	public static void deleteLocation(int idlocation) {
	    Modele.deleteLocation(idlocation);
	}

	public static void updateLocation(Location uneLocation) {
	    Modele.updateLocation(uneLocation);
	}

	
}














