package controleur;

import vue.VueConnexion;
import vue.VueGenerale;

public class NS {
	
	private static VueConnexion uneVueConnexion; 
	private static VueGenerale uneVueGenerale; 
	
	private static Utilisateur userConnecte = null; 
	
	public static void main(String[] args) {
		uneVueConnexion = new VueConnexion(); 
	}
	
	
	public static Utilisateur getUserConnecte() {
		return userConnecte;
	}


	public static void setUserConnecte(Utilisateur userConnecte) {
		NS.userConnecte = userConnecte;
	}


	public static void rendreVisibleVueConnexion(boolean action) {
		uneVueConnexion.setVisible(action);
	}
	
	public static void creerDetruireVueGenerale(boolean action) {
		if(action==true) {
			uneVueGenerale = new VueGenerale(); 
		}else {
			uneVueGenerale.dispose();
		}
	}
}
