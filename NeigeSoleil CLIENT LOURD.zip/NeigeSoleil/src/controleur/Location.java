package controleur;

public class Location {
	private int idlocation;
	private String dateDebut, dateFin, description;
	private int idappart, idclient;
	
	
	
	
	public Location(int idlocation, String dateDebut, String dateFin, String description, int idappart, int idclient) {
		super();
		this.idlocation = idlocation;
		this.dateDebut = dateDebut;
		this.dateFin = dateFin;
		this.description = description;
		this.idappart = idappart;
		this.idclient = idclient;
	}
	
	
	
	
	public Location( String dateDebut, String dateFin, String description, int idappart, int idclient) {
		super();
		this.idlocation = 0;
		this.dateDebut = dateDebut;
		this.dateFin = dateFin;
		this.description = description;
		this.idappart = idappart;
		this.idclient = idclient;
	}




	public int getIdlocation() {
		return idlocation;
	}




	public void setIdlocation(int idlocation) {
		this.idlocation = idlocation;
	}




	public String getDateDebut() {
		return dateDebut;
	}




	public void setDateDebut(String dateDebut) {
		this.dateDebut = dateDebut;
	}




	public String getDateFin() {
		return dateFin;
	}




	public void setDateFin(String dateFin) {
		this.dateFin = dateFin;
	}




	public String getDescription() {
		return description;
	}




	public void setDescription(String description) {
		this.description = description;
	}




	public int getIdappart() {
		return idappart;
	}




	public void setIdappart(int idappart) {
		this.idappart = idappart;
	}




	public int getIdclient() {
		return idclient;
	}




	public void setIdclient(int idclient) {
		this.idclient = idclient;
	}
	

	
	
	
}



