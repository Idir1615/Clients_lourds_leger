package controleur;

public class Proprietaire {
	private int idproprio;
	private String nom, prenom, email, mdp, adresse;
	public Proprietaire(int idproprio, String nom, String prenom, String email, String mdp, String adresse) {
		super();
		this.idproprio = idproprio;
		this.nom = nom;
		this.prenom = prenom;
		this.email = email;
		this.mdp = mdp;
		this.adresse = adresse;
	}
	
	public Proprietaire( String nom, String prenom, String email, String mdp, String adresse) {
		super();
		this.idproprio = 0;
		this.nom = nom;
		this.prenom = prenom;
		this.email = email;
		this.mdp = mdp;
		this.adresse = adresse;
	}

	public int getIdproprio() {
		return idproprio;
	}

	public void setIdproprio(int idproprio) {
		this.idproprio = idproprio;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMdp() {
		return mdp;
	}

	public void setMdp(String mdp) {
		this.mdp = mdp;
	}

	public String getAdresse() {
		return adresse;
	}

	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	
	
}

